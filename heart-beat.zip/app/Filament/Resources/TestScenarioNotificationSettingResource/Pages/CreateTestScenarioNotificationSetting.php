<?php

namespace App\Filament\Resources\TestScenarioNotificationSettingResource\Pages;

use App\Filament\Resources\TestScenarioNotificationSettingResource;
use Filament\Resources\Pages\CreateRecord;

class CreateTestScenarioNotificationSetting extends CreateRecord
{
    protected static string $resource = TestScenarioNotificationSettingResource::class;
}
