<?php

namespace App\Filament\Resources\TestScenarioResource\Pages;

use App\Filament\Resources\TestScenarioResource;
use Filament\Resources\Pages\CreateRecord;

class CreateTestScenario extends CreateRecord
{
    protected static string $resource = TestScenarioResource::class;
}
