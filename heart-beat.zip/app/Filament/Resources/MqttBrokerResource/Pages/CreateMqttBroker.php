<?php

namespace App\Filament\Resources\MqttBrokerResource\Pages;

use App\Filament\Resources\MqttBrokerResource;
use Filament\Resources\Pages\CreateRecord;

class CreateMqttBroker extends CreateRecord
{
    protected static string $resource = MqttBrokerResource::class;
}
