<?php

namespace App\Filament\Resources\NotificationTypeResource\Pages;

use App\Filament\Resources\NotificationTypeResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNotificationType extends CreateRecord
{
    protected static string $resource = NotificationTypeResource::class;
}
