<x-filament::page>
    {{ $this->form }}
</x-filament::page>
